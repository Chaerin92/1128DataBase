const express = require('express');
const router = express.Router();
const postsController = require('../controllers/postsController');

// 전체 게시물 목록
router.get('/', postsController.list);

// 게시물 상세 + 조회수 증가
router.get('/:id', postsController.detail);

// 새 게시물 추가
router.post('/', postsController.create);

// 게시물 수정
router.put('/:id', postsController.update);

// 게시물 삭제
router.delete('/:id', postsController.delete);

module.exports = router;
