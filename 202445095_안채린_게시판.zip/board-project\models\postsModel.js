const pool = require('../config/db');

const Posts = {
    getAll: async (search) => {
        const sql = search
            ? 'SELECT * FROM posts WHERE title LIKE ? ORDER BY id DESC'
            : 'SELECT * FROM posts ORDER BY id DESC';
        const [rows] = await pool.query(sql, search ? [`%${search}%`] : []);
        return rows;
    },

    getById: async (id) => {
        const [rows] = await pool.query('SELECT * FROM posts WHERE id = ?', [id]);
        return rows[0];
    },

    increaseViews: async (id) => {
        await pool.query('UPDATE posts SET views = views + 1 WHERE id = ?', [id]);
    },

    create: async (title, content, category) => {
        const [result] = await pool.query(
            'INSERT INTO posts (title, content, category) VALUES (?, ?, ?)',
            [title, content, category]
        );
        return result.insertId;
    },

    update: async (id, title, content, category) => {
        await pool.query(
            'UPDATE posts SET title = ?, content = ?, category = ? WHERE id = ?',
            [title, content, category, id]
        );
    },

    delete: async (id) => {
        await pool.query('DELETE FROM posts WHERE id = ?', [id]);
    }
};

module.exports = Posts;
