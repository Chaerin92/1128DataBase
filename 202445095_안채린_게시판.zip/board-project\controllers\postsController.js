const Posts = require('../models/postsModel');

const postsController = {
    list: async (req, res) => {
        const search = req.query.search || '';
        const posts = await Posts.getAll(search);
        res.json(posts);
    },

    detail: async (req, res) => {
        const id = req.params.id;

        // 조회수 증가
        await Posts.increaseViews(id);

        // 게시물 가져오기
        const post = await Posts.getById(id);
        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }
        res.json(post);
    },

    create: async (req, res) => {
        const { title, content, category } = req.body;
        const id = await Posts.create(title, content, category);
        res.json({ id });
    },

    update: async (req, res) => {
        const id = req.params.id;
        const { title, content, category } = req.body;
        await Posts.update(id, title, content, category);
        res.json({ message: 'Updated' });
    },

    delete: async (req, res) => {
        const id = req.params.id;
        await Posts.delete(id);
        res.json({ message: 'Deleted' });
    }
};

module.exports = postsController;
