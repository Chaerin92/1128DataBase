const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "root1234",
    database: "board",
    charset: "utf8mb4"   // <- 반드시 추가
});

module.exports = pool;
